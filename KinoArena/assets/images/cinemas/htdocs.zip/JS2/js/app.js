document.addEventListener('DOMContentLoaded', function () {
    function router() {
        var page = location.hash.slice(1);

        switch (page) {
            case 'login':
                loginController();
                break;
            case 'praskovi':
                praskoviController();
                break;
            case 'addPraskova':
                addPraskovaController();
                break;

            default:
                loginController();
                break;
        }
    }

    window.addEventListener('hashchange', router);
    router();
});