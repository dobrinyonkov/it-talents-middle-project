function praskoviController() {
    if (sessionStorage.getItem('isLogged') == null) {
        location.replace("#login");
    } else {
        var praskoviTemplate = document.getElementById('praskoviTemplate').innerHTML;
        var praskovi = praskoviService.getAll();

        var praskoviPage = Handlebars.compile(praskoviTemplate);
        document.querySelector('main').innerHTML = praskoviPage({ praskovi: praskovi });



    }
};