function addPraskovaController() {
    if (sessionStorage.getItem('isLogged') == null) {
        location.replace("#login");
    } else {
        var praskoviTemplate = document.getElementById('addPraskovaTemplate').innerHTML;
        document.querySelector('main').innerHTML = praskoviTemplate;

        document.getElementById('add').addEventListener('click', function (event) {
            event.preventDefault();

            var name = document.querySelector('#name').value;
            var link = document.querySelector('#url').value;
            var quantity = document.querySelector('#quantity').value;

            praskoviService.addPraskova(new Praskova(name, link, quantity));

            location.replace('#praskovi');
        });
    }
}