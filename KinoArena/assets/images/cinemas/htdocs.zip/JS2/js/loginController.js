function loginController() {
    var loginHTML = document.getElementById('loginTemplate').innerHTML;
    document.querySelector('main').innerHTML = loginHTML;

    document.getElementById('login').addEventListener('click', function (event) {
        event.preventDefault();

        var user = document.querySelector('#user').value;
        var pass = document.querySelector('#pass').value;


        if (userService.login(user, pass)) {
            sessionStorage.setItem('isLogged', true);

            location.replace('#praskovi');
        } else {
            alert("Nevalidno");
        }
    });
}
