var userService = (function () {
    var users = [
        { username: "Gosho", password: '1234' },
        { username: "Pesho", password: 'azSymPesho1' },
        { username: "Penka", password: 'tainoObichamAzis1' }
    ];

    function UserService() {
    }

    UserService.prototype.login = function (user, pass) {
        return !!users.find(function (u) {
            return u.username === user &&
                u.password === pass;
        });
    }

    return new UserService();
})(); 