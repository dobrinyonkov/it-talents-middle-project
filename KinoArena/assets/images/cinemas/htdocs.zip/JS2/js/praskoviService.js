var Praskova;

var praskoviService = (function () {

    Praskova = function (name, imageUrl, quantity) {
        this.name = name;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
    }

    var praskovi = [];

    praskovi.push(new Praskova('Meikrest', 'http://www.razsadnik-elit.com/images/stories/fruit/3/maykrest%209.jpg', 20));
    praskovi.push(new Praskova('Rish Mei', 'http://www.razsadnik-elit.com/images/stories/fruit/3/maykrest%209.jpg', 320));
    praskovi.push(new Praskova('Royal Glori', 'http://www.razsadnik-elit.com/images/stories/fruit/3/maykrest%209.jpg', 250));
    praskovi.push(new Praskova('Simfoniq', 'http://www.razsadnik-elit.com/images/stories/fruit/3/20100801peach.jpg', 26720));
    praskovi.push(new Praskova('Symyrset', 'http://www.razsadnik-elit.com/images/stories/fruit/3/samarset%201.jpg', 520));

    return {
        getAll: function () {
            return praskovi.slice();
        },
        addPraskova: function (praskova) {
            if (praskova instanceof Praskova)
                praskovi.push(praskova);
        }
    };

})();