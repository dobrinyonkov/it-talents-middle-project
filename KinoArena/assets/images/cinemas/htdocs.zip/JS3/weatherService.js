// function load(city, callBack, errCallback) {
//     const HTTP_OK = 200;
//     var xhr;

//     if (XMLHttpRequest) {
//         xhr = new XMLHttpRequest();
//     }
//     else {
//         xhr = new ActiveXObject();// IE 7-
//     }

//     xhr.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&apikey=f631fd357c75163a46154773a513dd64', true);
//     xhr.send(null);

//     xhr.addEventListener('load', function () {
//         if (xhr.status >= HTTP_OK && xhr.status < 300) {
//             var data = JSON.parse(xhr.responseText);
//             callBack(data);
//         } else {
//             errCallback(xhr.statusText);
//         }
//     });
// }


function load(city) {
    return new Promise(function (resolve, reject) {
        const HTTP_OK = 200;
        var xhr;

        if (XMLHttpRequest) {
            xhr = new XMLHttpRequest();
        }
        else {
            xhr = new ActiveXObject();// IE 7-
        }

        xhr.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&apikey=f631fd357c75163a46154773a513dd64', true);
        xhr.send(null);

        xhr.addEventListener('load', function () {
            if (xhr.status >= HTTP_OK && xhr.status < 300) {
                var data = JSON.parse(xhr.responseText);
                resolve(data);
            } else {
                reject(xhr.statusText);
            }
        });
    });
}