document.addEventListener('DOMContentLoaded', function () {

    document.getElementById('download').addEventListener('click', function () {
        var city = document.querySelector('input').value;
        // load(city, function (data) {
        //     var html = "<p> Weather: " + data.weather[0].main + " </p>";
        //     html += "<p> Temperatura: " + (data.main.temp - 273).toFixed(1) + " gradusa </p>";
        //     html += "<p> Pressure: " + data.main.pressure + " Hpa </p>";
        //     html += "<img src='http://openweathermap.org/img/w/" + data.weather[0].icon + ".png'/>"
        //     document.getElementById('result').innerHTML = html;
        // }, function (error) {
        //     document.getElementById('result').innerHTML = "<p style='color:red'> Sorry, the following error ocurred : " + error + " </p>";
        // });

        load(city)
            .then(function (data) {
                var html = "<p> Weather: " + data.weather[0].main + " </p>";
                html += "<p> Temperatura: " + (data.main.temp - 273).toFixed(1) + " gradusa </p>";
                html += "<p> Pressure: " + data.main.pressure + " Hpa </p>";
                html += "<img src='http://openweathermap.org/img/w/" + data.weather[0].icon + ".png'/>"
                document.getElementById('result').innerHTML = html;
            })
            .catch(function (error) {
                document.getElementById('result').innerHTML = "<p style='color:red'> Sorry, the following error ocurred : " + error + " </p>";
            });
    });
});
