document.addEventListener('DOMContentLoaded', function () {
    function load() {

        var xhr;
        if (XMLHttpRequest) {
            xhr = new XMLHttpRequest();
        }
        else {
            // IE 7-
            xhr = new ActiveXObject();
        }


        var city = document.querySelector('input').value;
        xhr.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=' + city + '&apikey=f631fd357c75163a46154773a513dd64', true);
        xhr.send(null);

        xhr.addEventListener('load', function () {
            var data = JSON.parse(xhr.responseText);

            var html = "<p> Weather: " + data.weather[0].main + " </p>";
            html += "<p> Temperatura: " + (data.main.temp - 273).toFixed(1) + " gradusa </p>";
            html += "<p> Pressure: " + data.main.pressure + " Hpa </p>";
            html += "<img src='http://openweathermap.org/img/w/" + data.weather[0].icon + ".png'/>"

            document.getElementById('result').innerHTML = html;
        });
    }

    document.getElementById('download').addEventListener('click', function () {
        load();
    });
});

