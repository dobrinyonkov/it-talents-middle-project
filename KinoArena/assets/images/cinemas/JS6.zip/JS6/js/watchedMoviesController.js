function watchedMoviesController() {
    var templateText = $('#personal_movies_template').text();
    var template = Handlebars.compile(templateText);

    var movies = moviesService.getWatched();
    $('#home_page').hide();
    $('#personal_page').show();
    $('section').html('');
    $('#personal_table tbody').remove();
    $('#personal_table').append($(template({ movies: movies })));

    $('.moreInfo').on('click', function () {
        var templateText = $('#movie_detail_template').text();
        var template = Handlebars.compile(templateText);
        var title = $(this).parent().parent().children().eq(0).text().trim();


        moviesService.getDetails(title).then(function (details) {
            var infoEl = template(details);
            $('section').html(infoEl);
        });
    });
}

