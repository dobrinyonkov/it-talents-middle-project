function homeController() {

    function showMoviesTable(movies) {
        var templateText = $('#all_movies_template').text();
        var template = Handlebars.compile(templateText);

        $('#main_table tbody').remove();
        $('#main_table').append($(template({ movies: movies })));

        $('input.favorite').on('click', function () {
            var title = $(this).parent().parent().children().eq(0).text().trim();
            moviesService.toggleFavorite(title);
        });

        $('input.watched').on('click', function () {
            var title = $(this).parent().parent().children().eq(0).text().trim();
            moviesService.toggleWatched(title);
        });
    }

    $(function () {
        moviesService.loadMovies().then(function (movies) {

            $('#home_page').show();
            $('#personal_page').hide();
            $('#login').hide();
            showMoviesTable(movies);

            var ascending = false;

            $('#sort').on('click', function () {
                ascending = !ascending;
                //sort
                movies.sort(function (m1, m2) {
                    if (m1.Title > m2.Title) {
                        return ascending ? 1 : -1;
                    }
                    if (m1.Title < m2.Title) {
                        return ascending ? -1 : 1;
                    }

                    return 0;
                });
                showMoviesTable(movies);
            });


            $('#show_watched').on('click', function () {
                location.replace('#watched');
            });

            $('#show_favorites').on('click', function () {
                location.replace('#favorites');
            });
        });
    });
}