function router() {
    var page = location.hash.slice(1);

    if (!sessionStorage.getItem('userId') && page != 'login') {
        location.replace('#login');
        return;
    }

    switch (page) {
        case 'login':
            loginController();
            break;
        case 'watched':
            watchedMoviesController();
            break;
        case 'favorites':
            favoriteMoviesController();
            break;
        default:
            homeController();
            break;
    }

}

$(window).on('hashchange', router);
router();