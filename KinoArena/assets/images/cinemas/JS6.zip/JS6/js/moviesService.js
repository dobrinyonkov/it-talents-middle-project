var moviesService = (function () {
    var movies;
    var userData = [];

    function MoviesService() {
        userData = JSON.parse(sessionStorage.getItem('userData'));
        if (!userData) {
            sessionStorage.setItem('userData', '[]');
        } else {
            var userId = JSON.parse(sessionStorage.getItem('userId'));

            if (userData[userId])
                movies = JSON.parse(userData[userId]);
        }
    }

    function saveInStorage() {
        var userId = JSON.parse(sessionStorage.getItem('userId'));
        userData[userId] = movies;
        sessionStorage.setItem('userData', JSON.stringify(userData));
        console.log(userData);
    }

    MoviesService.prototype.loadMovies = function () {
        return new Promise(function (resolve, reject) {
            if (movies != undefined) {
                resolve(movies);
                return;
            }

            $.get('http://www36.imperiaonline.org/movies.php').then(function (m) {
                movies = JSON.parse(m);
                movies.forEach(movie => {
                    movie.watched = false;
                    movie.favorite = false;
                    movie.notes = '';
                });

                var userId = sessionStorage.getItem('userId');
                saveInStorage();
                resolve(movies);
            });
        });
    }

    MoviesService.prototype.getAllMovies = function () {
        return movies;
    }

    MoviesService.prototype.toggleWatched = function (title) {
        var movie = movies.find(movie => movie.Title === title);
        if (movie) {
            movie.watched = !movie.watched;
            saveInStorage();
        } else {
            throw new Error('No such movie ' + title);
        }
    }

    MoviesService.prototype.toggleFavorite = function (title) {
        var movie = movies.find(movie => movie.Title === title);
        if (movie) {
            movie.favorite = !movie.favorite;
            if (movie.favorite == false) {
                movie.notes = '';
            }
            saveInStorage();
        }
        else {
            throw new Error('No such movie ' + title);
        }
    }

    MoviesService.prototype.getWatched = function () {
        return movies.filter(movie => movie.watched);
    }

    MoviesService.prototype.getFavorites = function () {
        return movies.filter(movie => movie.favorite);
    }

    MoviesService.prototype.addNote = function (title, notes) {
        var movie = movies.find(movie => movie.Title === title);
        if (movie) {
            movie.notes = notes;
            saveInStorage();
        }
        else {
            throw new Error('No such movie ' + title);
        }
    }

    MoviesService.prototype.getDetails = function (title) {
        return new Promise(function (resolve, reject) {
            $.get('https://api.themoviedb.org/3/search/movie?' +
                'api_key=d9c8f259630fa46418ae1ddaabe71b6c' +
                '&language=en-US&query=' + title +
                '&page=1&include_adult=true')
                .then(function (data) {
                    resolve(data.results[0]);
                });
        });
    }

    return new MoviesService();
})();
