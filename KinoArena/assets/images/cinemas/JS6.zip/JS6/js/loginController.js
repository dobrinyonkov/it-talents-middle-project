function loginController() {
    $('#login').show();
    $('#home_page').hide();
    $('#personal_page').hide();

    $('#loginBut').on('click', function (event) {
        event.preventDefault();
        if (($('#user').val() == 'gosho')) {
            sessionStorage.setItem("userId", 1);
            location.replace('#home');
        }

        if (($('#user').val() == 'pesho')) {
            sessionStorage.setItem("userId", 2);
            location.replace('#home');
        }
    });
}